'use client';

import { useMemo, useState } from 'react';
import Image from 'next/image';

const products = [
  { id: 'rank-hero', category: 'RANKS', name: 'HERO', price: 149, desc: 'Exclusive chat prefix, cosmetics & premium perks.', badge: 'POPULAR', icon: '✦' },
  { id: 'rank-titan', category: 'RANKS', name: 'TITAN', price: 299, desc: 'Priority queue, premium cosmetics & extra perks.', icon: '◆' },
  { id: 'rank-legend', category: 'RANKS', name: 'LEGEND', price: 599, desc: 'The full premium experience with elite perks.', badge: 'ELITE', icon: '♛' },
  { id: 'coins-1', category: 'COINS', name: '1,000 COINS', price: 49, desc: 'Top up your MINE MC balance.', icon: '◈' },
  { id: 'coins-5', category: 'COINS', name: '5,500 COINS', price: 199, desc: 'Bonus coin pack for the in-game economy.', badge: '+10% BONUS', icon: '◈' },
  { id: 'key-rare', category: 'CRATE KEYS', name: 'RARE KEY', price: 39, desc: 'Unlock one Rare Crate.', icon: '🔑' },
  { id: 'key-epic', category: 'CRATE KEYS', name: 'EPIC KEY', price: 79, desc: 'Unlock one Epic Crate.', badge: 'HOT', icon: '🔑' },
  { id: 'season-1', category: 'SEASON', name: 'SEASON PASS', price: 249, desc: 'Unlock the current seasonal rewards track.', icon: '⚡' },
];

const categories = ['ALL', 'RANKS', 'COINS', 'CRATE KEYS', 'SEASON'];

export default function StoreClient() {
  const [category, setCategory] = useState('ALL');
  const [selected, setSelected] = useState<(typeof products)[number] | null>(null);
  const [username, setUsername] = useState('');
  const [orderId, setOrderId] = useState('');
  const [utr, setUtr] = useState('');
  const [upiId, setUpiId] = useState('6207867258@fam');
  const [busy, setBusy] = useState(false);
  const [paidSubmitted, setPaidSubmitted] = useState(false);
  const filtered = useMemo(() => category === 'ALL' ? products : products.filter(p => p.category === category), [category]);

  async function startUPI() {
    if (!selected) return;
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username.trim())) return alert('Please enter a valid Minecraft username.');
    setBusy(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), productId: selected.id }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not create order.');
      setOrderId(data.orderId);
      setUpiId(data.upiId);
      setPaidSubmitted(false);
    } catch (e) {
      alert(e instanceof Error ? e.message : 'Something went wrong.');
    } finally {
      setBusy(false);
    }
  }

  async function submitPayment() {
    if (!orderId) return;
    if (!/^[A-Za-z0-9-]{6,40}$/.test(utr.trim())) return alert('Enter the UPI transaction ID / UTR from your payment app.');
    setBusy(true);
    try {
      const res = await fetch(`/api/orders/${orderId}/payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ utr: utr.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not submit payment reference.');
      setPaidSubmitted(true);
    } catch (e) {
      alert(e instanceof Error ? e.message : 'Something went wrong.');
    } finally {
      setBusy(false);
    }
  }

  function closeModal() {
    if (busy) return;
    setSelected(null);
    setOrderId('');
    setUtr('');
    setPaidSubmitted(false);
  }

  const upiLink = selected && orderId
    ? `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent('MINE MC')}&am=${selected.price}&cu=INR&tn=${encodeURIComponent(`MINE MC ${selected.name} ${orderId}`)}`
    : '#';

  return <>
    <div className="site-shell">
      <div className="particles" aria-hidden="true">{Array.from({ length: 34 }).map((_, i) => <i key={i} style={{ left: `${(i * 29) % 100}%`, animationDelay: `${(i % 11) * -1.7}s`, animationDuration: `${8 + (i % 7)}s` }} />)}</div>
      <header className="nav">
        <a className="brand" href="#top"><Image src="/mine-mc-logo.png" alt="MINE MC" width={54} height={54} priority /><span><b>MINE</b><em>MC</em></span></a>
        <nav><a href="#store">STORE</a><a href="#how">HOW IT WORKS</a><a href="#faq">FAQ</a></nav>
        <a className="discord" href="https://discord.gg/kT8WXQCaN5" target="_blank" rel="noreferrer">JOIN DISCORD ↗</a>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-glow" />
          <div className="hero-copy">
            <div className="eyebrow"><span className="live-dot" /> MINE MC OFFICIAL STORE</div>
            <h1>POWER UP<br /><span>YOUR GAME.</span></h1>
            <p>Ranks, coins, crate keys & seasonal upgrades — pay securely through UPI and get your purchase delivered after payment verification.</p>
            <div className="hero-actions"><a className="primary" href="#store">EXPLORE STORE <span>↓</span></a><a className="ghost" href="https://discord.gg/kT8WXQCaN5" target="_blank" rel="noreferrer">COMMUNITY DISCORD ↗</a></div>
            <div className="stats"><div><strong>24/7</strong><small>ONLINE</small></div><div><strong>UPI</strong><small>PAYMENTS</small></div><div><strong>SECURE</strong><small>VERIFICATION</small></div></div>
          </div>
          <div className="hero-art"><div className="ring ring1" /><div className="ring ring2" /><div className="cube c1" /><div className="cube c2" /><div className="cube c3" /><div className="character"><div className="head" /><div className="body" /><div className="leg l1" /><div className="leg l2" /></div><div className="art-tag">MINE MC<br /><small>NETWORK</small></div></div>
        </section>

        <section className="marquee"><div>⚡ UPI PAYMENT <span>•</span> PREMIUM PERKS <span>•</span> SEASONAL CONTENT <span>•</span> COMMUNITY EVENTS <span>•</span> UPI PAYMENT <span>•</span></div></section>

        <section id="store" className="store-section">
          <div className="section-head"><div><div className="eyebrow">THE MARKETPLACE</div><h2>CHOOSE YOUR <span>UPGRADE.</span></h2></div><div className="server-status"><i /> SERVER ONLINE <b>●</b></div></div>
          <div className="tabs">{categories.map(c => <button key={c} className={category === c ? 'active' : ''} onClick={() => setCategory(c)}>{c}</button>)}</div>
          <div className="grid">{filtered.map(p => <article className="card" key={p.id} onClick={() => setSelected(p)}><div className="card-top"><div className="product-icon">{p.icon}</div>{p.badge && <span className="badge">{p.badge}</span>}</div><div className="product-type">{p.category}</div><h3>{p.name}</h3><p>{p.desc}</p><div className="card-bottom"><div><small>FROM</small><strong>₹{p.price}</strong></div><button>BUY NOW <span>→</span></button></div></article>)}</div>
        </section>

        <section id="how" className="how"><div className="section-head"><div><div className="eyebrow">UPI CHECKOUT</div><h2>FROM PAYMENT TO <span>SERVER.</span></h2></div></div><div className="steps"><div><b>01</b><h3>SELECT</h3><p>Choose your rank, coins, key or seasonal item.</p></div><div><b>02</b><h3>SCAN & PAY</h3><p>Scan the MINE MC QR or open your UPI app directly.</p></div><div><b>03</b><h3>SUBMIT UTR</h3><p>Enter the transaction reference from your UPI app.</p></div><div><b>04</b><h3>DELIVER</h3><p>After payment verification, your Minecraft command is sent automatically.</p></div></div></section>

        <section className="cta"><div><div className="eyebrow">READY?</div><h2>JOIN THE <span>MINE MC</span> COMMUNITY.</h2><p>Get announcements, support, giveaways and event updates on Discord.</p></div><a className="primary" href="https://discord.gg/kT8WXQCaN5" target="_blank" rel="noreferrer">JOIN DISCORD ↗</a></section>
      </main>

      <footer id="faq"><div className="brand"><Image src="/mine-mc-logo.png" alt="MINE MC" width={44} height={44} /><span><b>MINE</b><em>MC</em></span></div><p>© 2026 MINE MC NETWORK. NOT AFFILIATED WITH MOJANG.</p><a href="https://discord.gg/kT8WXQCaN5" target="_blank" rel="noreferrer">DISCORD ↗</a></footer>
    </div>

    {selected && <div className="modal-backdrop" onClick={() => !busy && closeModal()}><div className="modal payment-modal" onClick={e => e.stopPropagation()}><button className="close" onClick={closeModal}>×</button>
      {!orderId ? <>
        <div className="eyebrow">{selected.category} • UPI PAYMENT</div><h2>{selected.name}</h2><p>{selected.desc}</p><div className="price">₹{selected.price}</div>
        <label>MINECRAFT USERNAME<input autoFocus value={username} onChange={e => setUsername(e.target.value)} placeholder="YourInGameName" maxLength={16} /></label>
        <button className="primary full" onClick={startUPI} disabled={busy}>{busy ? 'CREATING ORDER…' : 'CONTINUE TO UPI'}</button>
        <small className="secure-note">Only UPI is enabled right now. Payment is verified before any Minecraft command is executed.</small>
      </> : <>
        <div className="eyebrow">SCAN TO PAY • {selected.name}</div><h2>PAY ₹{selected.price}</h2>
        <div className="qr-wrap"><Image src="/upi-qr.jpg" alt="MINE MC UPI QR code" width={300} height={533} className="upi-qr" /></div>
        <div className="upi-details"><span>UPI ID</span><strong>{upiId}</strong><button onClick={() => navigator.clipboard?.writeText(upiId)}>COPY</button></div>
        <a className="primary full" href={upiLink}>OPEN UPI APP ↗</a>
        <div className="order-code">ORDER <b>{orderId}</b></div>
        <label>UPI TRANSACTION ID / UTR<input value={utr} onChange={e => setUtr(e.target.value)} placeholder="Enter payment reference" maxLength={40} /></label>
        {paidSubmitted ? <div className="payment-success">✓ PAYMENT REFERENCE RECEIVED<br /><small>Your order is waiting for payment verification. Delivery will happen after verification.</small></div> : <button className="primary full" onClick={submitPayment} disabled={busy}>{busy ? 'SUBMITTING…' : 'I HAVE PAID — SUBMIT UTR'}</button>}
        <small className="secure-note">Do not close this window until you have saved your order ID and submitted the UTR.</small>
      </>}
    </div></div>}
  </>;
}
