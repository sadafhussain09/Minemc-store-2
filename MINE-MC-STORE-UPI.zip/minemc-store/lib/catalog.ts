export const fallbackProducts = [
  { id: 'rank-hero', slug: 'hero', name: 'HERO', type: 'RANK', description: 'Exclusive chat prefix, cosmetics and premium perks.', priceInr: 149, accent: 'orange' },
  { id: 'rank-titan', slug: 'titan', name: 'TITAN', type: 'RANK', description: 'Powerful rank perks, priority queue and cosmetics.', priceInr: 299, accent: 'gold' },
  { id: 'rank-legend', slug: 'legend', name: 'LEGEND', type: 'RANK', description: 'Top-tier rank with the full premium experience.', priceInr: 599, accent: 'red' },
  { id: 'coins-1', slug: 'coins-1', name: '1,000 COINS', type: 'COINS', description: 'Add 1,000 store coins to your account.', priceInr: 49, accent: 'gold' },
  { id: 'coins-5', slug: 'coins-5', name: '5,500 COINS', type: 'COINS', description: 'Bonus coin pack for the in-game economy.', priceInr: 199, accent: 'gold' },
  { id: 'key-rare', slug: 'rare-key', name: 'RARE KEY', type: 'KEY', description: 'Open one Rare Crate on the server.', priceInr: 39, accent: 'purple' },
  { id: 'key-epic', slug: 'epic-key', name: 'EPIC KEY', type: 'KEY', description: 'Open one Epic Crate on the server.', priceInr: 79, accent: 'red' },
  { id: 'season-1', slug: 'season-pass', name: 'SEASON PASS', type: 'SEASON_PASS', description: 'Unlock the current seasonal rewards track.', priceInr: 249, accent: 'cyan' },
];
