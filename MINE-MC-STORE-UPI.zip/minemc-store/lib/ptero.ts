export async function runMinecraftCommand(command: string) {
  const panel = process.env.PTERO_PANEL_URL?.replace(/\/$/, '');
  const server = process.env.PTERO_SERVER_ID;
  const token = process.env.PTERO_CLIENT_API_KEY;
  if (!panel || !server || !token) throw new Error('Pterodactyl is not configured');

  const response = await fetch(`${panel}/api/client/servers/${server}/command`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'Application/vnd.pterodactyl.v1+json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ command }),
    cache: 'no-store',
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Pterodactyl command failed (${response.status}): ${body}`);
  }
}

export function renderCommand(template: string, values: Record<string, string | number>) {
  return template.replace(/\{(\w+)\}/g, (_, key) => String(values[key] ?? `{${key}}`));
}
