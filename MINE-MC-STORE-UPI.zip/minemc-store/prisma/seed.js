const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const products = [
['hero','HERO','RANK','Exclusive chat prefix, cosmetics and premium perks.',149,'lp user {player} parent set hero'],
['titan','TITAN','RANK','Powerful rank perks, priority queue and cosmetics.',299,'lp user {player} parent set titan'],
['legend','LEGEND','RANK','Top-tier rank with the full premium experience.',599,'lp user {player} parent set legend'],
['coins-1','1,000 COINS','COINS','Add 1,000 store coins to your account.',49,'eco give {player} 1000'],
['coins-5','5,500 COINS','COINS','Bonus coin pack for the in-game economy.',199,'eco give {player} 5500'],
['rare-key','RARE KEY','KEY','Open one Rare Crate on the server.',39,'crate give {player} rare 1'],
['epic-key','EPIC KEY','KEY','Open one Epic Crate on the server.',79,'crate give {player} epic 1'],
['season-pass','SEASON PASS','SEASON_PASS','Unlock the current seasonal rewards track.',249,'lp user {player} parent set season']
];
(async()=>{for(const [slug,name,type,description,priceInr,command] of products){await prisma.product.upsert({where:{slug},update:{name,type,description,priceInr,command},create:{slug,name,type,description,priceInr,command}})}await prisma.$disconnect()})()
