import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'MINE MC • Official Store',
  description: 'MINE MC official Minecraft store — ranks, coins, crate keys and season passes.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
