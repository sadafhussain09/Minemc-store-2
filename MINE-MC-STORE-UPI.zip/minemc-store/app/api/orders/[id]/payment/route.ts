import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const body = await req.json();
    const utr = String(body.utr || '').trim();

    if (!/^[A-Za-z0-9-]{6,40}$/.test(utr)) {
      return NextResponse.json({ error: 'Enter the UPI transaction/UTR reference shown by your UPI app.' }, { status: 400 });
    }

    const order = await prisma.order.findUnique({ where: { id } });
    if (!order) return NextResponse.json({ error: 'Order not found.' }, { status: 404 });
    if (order.status !== 'PENDING') return NextResponse.json({ error: 'This order is already being processed.' }, { status: 409 });

    await prisma.order.update({
      where: { id },
      data: { paymentReference: `upi:${utr}` },
    });

    return NextResponse.json({ ok: true, message: 'Payment reference submitted. Your order will be delivered after payment verification.' });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Could not submit payment reference.' }, { status: 500 });
  }
}
