import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { fallbackProducts } from '@/lib/catalog';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const username = String(body.username || '').trim();
    const productId = String(body.productId || '').trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) {
      return NextResponse.json({ error: 'Enter a valid Minecraft username.' }, { status: 400 });
    }

    const dbProduct = await prisma.product.findUnique({ where: { id: productId } });
    let product = dbProduct ?? fallbackProducts.find(p => p.id === productId);
    if (!product) return NextResponse.json({ error: 'Product not found.' }, { status: 404 });

    if (!dbProduct) {
      product = await prisma.product.upsert({
        where: { slug: product.slug },
        update: {},
        create: {
          id: product.id,
          slug: product.slug,
          name: product.name,
          type: product.type as any,
          description: product.description,
          priceInr: product.priceInr,
          accent: product.accent,
        },
      });
    }

    const order = await prisma.order.create({
      data: {
        username,
        productId: product.id,
        amountInr: product.priceInr,
        status: 'PENDING',
      },
    });

    return NextResponse.json({
      orderId: order.id,
      amount: product.priceInr,
      currency: 'INR',
      upiId: process.env.NEXT_PUBLIC_UPI_ID || '6207867258@fam',
      payeeName: process.env.NEXT_PUBLIC_UPI_PAYEE || 'MINE MC',
      name: product.name,
      description: product.description,
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: 'Could not create UPI order.' }, { status: 500 });
  }
}
