import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { fallbackProducts } from '@/lib/catalog';
import { renderCommand, runMinecraftCommand } from '@/lib/ptero';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const secret = req.headers.get('x-admin-secret');
  if (!secret || secret !== process.env.ADMIN_SECRET) return new NextResponse('Unauthorized', { status: 401 });

  const { id } = await params;
  const order = await prisma.order.findUnique({ where: { id }, include: { product: true } });
  if (!order) return NextResponse.json({ error: 'Order not found.' }, { status: 404 });
  if (order.status === 'FULFILLED') return NextResponse.json({ ok: true, alreadyFulfilled: true });

  const product = order.product ?? fallbackProducts.find(p => p.id === order.productId);
  if (!product) return NextResponse.json({ error: 'Product missing.' }, { status: 500 });

  try {
    let command = (product as any).command as string | null | undefined;
    if (!command) {
      if (product.type === 'RANK') command = process.env.MINECRAFT_RANK_COMMAND || '';
      else if (product.type === 'COINS') command = process.env.MINECRAFT_COINS_COMMAND || '';
      else if (product.type === 'KEY') command = process.env.MINECRAFT_KEY_COMMAND || '';
      else command = `say Thank you {player} for supporting MINE MC!`;
    }

    const finalCommand = renderCommand(command, {
      player: order.username,
      package: product.slug,
      amount: order.amountInr,
      orderId: order.id,
    });

    await runMinecraftCommand(finalCommand);
    await prisma.order.update({
      where: { id: order.id },
      data: { status: 'FULFILLED', fulfilledAt: new Date() },
    });

    return NextResponse.json({ ok: true, status: 'FULFILLED', command: finalCommand });
  } catch (e) {
    console.error('UPI fulfillment failed:', e);
    await prisma.order.update({ where: { id: order.id }, data: { status: 'PAID' } });
    return NextResponse.json({ error: 'Payment verified but delivery failed. Order is marked PAID for retry.' }, { status: 500 });
  }
}
