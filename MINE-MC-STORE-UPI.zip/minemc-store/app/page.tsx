import StoreClient from '@/components/StoreClient';

export default function Home() {
  return <StoreClient />;
}
